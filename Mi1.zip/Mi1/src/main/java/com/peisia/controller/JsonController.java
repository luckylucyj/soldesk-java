package com.peisia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.peisia.dto.Dog;

@RequestMapping("/api/*")
@Controller
public class JsonController {
@GetMapping("/dogOne")
public Dog getDogOne() {
	Dog dog=new Dog();
	dog.setName("멍멍이");
	dog.setAge(5);
	dog.setSex("female");
	return dog;
}
}
