package com.peisia.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.client.RestTemplate;

import com.peisia.dto.GuestDto;
import com.peisia.service.GuestService;
import com.peisia.spring.atmosphere.AtmosphereDto;
import com.peisia.spring.atmosphere.Item;
import com.peisia.spring.seoul.pharmacy.Row;
import com.peisia.spring.seoul.pharmacy.SPharmacyDto;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/guest/*")
@AllArgsConstructor
@Controller
@SessionAttributes("x") // 1. 이 어노테이션을 붙이고
public class GuestController {

	private GuestService service;
	private final ResourceLoader resourceLoader;

	@GetMapping("/getList")
	public void getList(@RequestParam(value = "currentPage", defaultValue = "1") int currentPage, Model model) {
		ArrayList<GuestDto> list = service.getList(model, currentPage);
		int totalPage = service.getTotalPage(); // 총 페이지 수 가져오기
		model.addAttribute("list", list);
		model.addAttribute("totalPage", totalPage);
	}

	@GetMapping({ "/read", "/modify" })
	public void read(@RequestParam("bno") Long bno, Model model) {
		log.info("컨트롤러 ==== 글번호 ===============" + bno);
		model.addAttribute("read", service.read(bno));
	}

	@GetMapping("/del")
	public String del(@RequestParam("bno") Long bno) {
		log.info("컨트롤러 ==== 글번호 ===============" + bno);
		service.del(bno);
		return "redirect:/guest/getList?currentPage=1"; // 책 p.245 참고
	}

	@PostMapping("/write")
	public String write(GuestDto gvo) {
		service.write(gvo);
		return "redirect:/guest/getList?currentPage=1"; // 책 p.245 참고
	}

	@GetMapping("/write") // 책 p.239 /write 중복이지만 이건 글쓰기 화면을 위한 url 매핑
	public void write() {

	}

	@PostMapping("/modify")
	public String modify(GuestDto gvo) {
		service.modify(gvo);
		return "redirect:/guest/getList?currentPage=1";
	}

	@GetMapping("/aaa")
	public void sessionExample(HttpSession session) {
		session.setAttribute("cat", "고양이");
	}

	// 스프링 세션 사용하기
	@GetMapping("/a")
	public void a(HttpSession s, Model m) {
		s.setAttribute("a", "개");
		// 2. 모델에 x 키로 고양이 저장. ( 세션에도 x 키로 고양이가 저장됨 )
		m.addAttribute("x", "고양이");
	}

	@RequestMapping("/seoulPharmacy")
	public void seoul(Model m) {
		String API_URL = "http://openapi.seoul.go.kr:8088/6470426c6f6a65793131326768447459/json/TbPharmacyOperateInfo/1/5/";

		RestTemplate restTemplate = new RestTemplate();

		// URI로 변환
		URI uri;
		try {
			uri = new URI(API_URL);
		} catch (URISyntaxException e) {
			e.printStackTrace();
			return; // 예외 발생 시 종료
		}
//	    String s=restTemplate.getForObject(uri, String.class);
//	    log.info("======😀😀😀😀 😀😀  나오나? "+s);
		SPharmacyDto sp = restTemplate.getForObject(uri, SPharmacyDto.class); // 자기 클래스로 바꾸시오..
//		List<Map<String, String>> pharmacyList = new ArrayList<>();
		List<Row> row = sp.TbPharmacyOperateInfo.row;
		m.addAttribute("row", row);
	}

	@RequestMapping("/culture")
	public void c(Model m) {
		String API_URL = "http://api.kcisa.kr/openapi/API_CIA_144/request?serviceKey=1f061410-9ea1-459a-a2b6-d40514901f6c&numOfRows=10&pageNo=1";

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		RestTemplate restTemplate = new RestTemplate();

		URI uri = null;

		try {
			uri = new URI(API_URL);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		ResponseEntity<String> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, requestEntity, String.class);

		// API 요청에 대한 응답을 ResponseEntity로 받아옴
//	    ResponseEntity<String> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, null, String.class);

		// ResponseEntity의 body를 JSON으로 파싱하여 처리
		String s = responseEntity.getBody();

		log.info("잘찍히나?" + s);
		// 여기서 responseBody는 JSON 형식의 문자열입니다. 이를 원하는 방식으로 파싱하여 사용하면 됩니다.
	}
	

	


}
