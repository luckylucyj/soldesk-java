package com.peisia.controller;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.peisia.spring.atmosphere.AtmosphereDto;
import com.peisia.spring.atmosphere.Item;
import com.peisia.spring.mi.vo.kw.KWeatherDto;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

@AllArgsConstructor
@Controller
@Log4j
@RequestMapping("/animal/*")
public class AnimalController {
    @RequestMapping("/animalForest")
    public void AnimalContoller(Model m) {
    	
    	String API_URL = "https://api.nookipedia.com/villagers";
    	RestTemplate restTemplate = new RestTemplate();
    	
		URI uri = null; // java.net.URI 임포트 하셈
		try {
			uri = new URI(API_URL);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		
		
	    String s=restTemplate.getForObject(uri, String.class);
	    log.info("======😀😀😀😀 😀😀  나오나? "+s);
//		AtmosphereDto ap = restTemplate.getForObject(uri, AtmosphereDto.class); // 자기 클래스로 바꾸시오..
//		List<Item> air = ap.response.body.items;
//		m.addAttribute("air", air);
    }
}
