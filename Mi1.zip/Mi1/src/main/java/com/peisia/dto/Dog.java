package com.peisia.dto;

import lombok.Data;

@Data
public class Dog {
	private String name;
	private Integer age;
	// 성별도 적어주기
	private String sex;
}
