package com.peisia.dto;

import lombok.Data;

@Data	
public class Cat {	
	private String name;
	private Integer age;
}	
