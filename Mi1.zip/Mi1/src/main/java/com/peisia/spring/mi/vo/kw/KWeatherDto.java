
package com.peisia.spring.mi.vo.kw;

public class KWeatherDto {

    public Response response;

}
