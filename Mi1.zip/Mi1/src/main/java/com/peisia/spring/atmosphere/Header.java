package com.peisia.spring.atmosphere;

import lombok.Data;

@Data
public class Header {

    public String resultMsg;
    public String resultCode;

}
