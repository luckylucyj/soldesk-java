package com.peisia.spring.pharmacy;

public class Header {

    public String resultCode;
    public String resultMsg;

}
