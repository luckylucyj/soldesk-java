package com.peisia.spring.pharmacy;

public class Item {
	public String dutyAddr;
	public String dutyFax;
	public String dutyName;
	public String dutyTel1;
	public Integer dutyTime1c;
	public String dutyTime1s;
	public Integer dutyTime2c;
	public String dutyTime2s;
	public Integer dutyTime3c;
	public String dutyTime3s;
	public Integer dutyTime4c;
	public String dutyTime4s;
	public Integer dutyTime5c;
	public String dutyTime5s;
	public Integer dutyTime6c;
	public String dutyTime6s;
	public String hpid;
	public String postCdn1;
	public String postCdn2;
	public Integer rnum;
	public Float wgs84Lat;
	public Float wgs84Lon;
	public String dutyMapimg;
	public Integer dutyTime7c;
	public Integer dutyTime7s;
	public Integer dutyTime8c;
	public Integer dutyTime8s;
	public int dutyTime;
	public String dutyEtc;
	public String dutyInf;

}
