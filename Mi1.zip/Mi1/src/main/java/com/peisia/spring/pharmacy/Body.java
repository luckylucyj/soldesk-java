package com.peisia.spring.pharmacy;

public class Body {

    public Items items;
    public Integer numOfRows;
    public Integer pageNo;
    public Integer totalCount;

}
