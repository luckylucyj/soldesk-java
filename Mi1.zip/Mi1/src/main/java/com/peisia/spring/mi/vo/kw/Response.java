
package com.peisia.spring.mi.vo.kw;

public class Response {

    public Header header;
    public Body body;

}
