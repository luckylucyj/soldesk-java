
package com.peisia.spring.atmosphere;

import lombok.Data;

@Data
public class Response {

    public Body body;
    public Header header;

}
