
package com.peisia.spring.atmosphere;

import java.util.List;

import lombok.Data;

@Data
public class Body {

    public Integer totalCount;
    public List<Item> items;
    public Integer pageNo;
    public Integer numOfRows;

}
