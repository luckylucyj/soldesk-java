package com.peisia.spring.pharmacy;

public class Items {

    public Item item;

}
