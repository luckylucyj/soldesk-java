package com.peisia.spring.seoul.pharmacy;

public class Result {

    public String code;
    public String message;

}
