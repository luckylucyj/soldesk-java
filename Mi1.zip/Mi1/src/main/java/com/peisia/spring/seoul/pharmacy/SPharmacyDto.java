package com.peisia.spring.seoul.pharmacy;

import lombok.Data;

@Data
public class SPharmacyDto {

    public TbPharmacyOperateInfo TbPharmacyOperateInfo;

}
