
package com.peisia.spring.atmosphere;

import lombok.Data;

@Data
public class Item {

    public String daegu;
    public String chungnam;
    public String incheon;
    public String daejeon;
    public String gyeongbuk;
    public String sejong;
    public String gwangju;
    public String jeonbuk;
    public String gangwon;
    public String ulsan;
    public String jeonnam;
    public String seoul;
    public String busan;
    public String jeju;
    public String chungbuk;
    public String gyeongnam;
    public String dataTime;
    public String dataGubun;
    public String gyeonggi;
    public String itemCode;

}
