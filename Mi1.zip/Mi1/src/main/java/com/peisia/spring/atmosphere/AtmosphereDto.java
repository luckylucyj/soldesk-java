
package com.peisia.spring.atmosphere;

import lombok.Data;

@Data
public class AtmosphereDto {

    public Response response;

}
