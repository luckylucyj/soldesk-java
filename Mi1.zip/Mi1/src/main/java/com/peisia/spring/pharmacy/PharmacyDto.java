package com.peisia.spring.pharmacy;

public class PharmacyDto {

    public Response response;

}
