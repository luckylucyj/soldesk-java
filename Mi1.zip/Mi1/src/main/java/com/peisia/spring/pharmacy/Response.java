package com.peisia.spring.pharmacy;

public class Response {

    public Header header;
    public Body body;

}
