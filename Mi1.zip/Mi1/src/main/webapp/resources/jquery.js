/**
 * 
 */

$(function() {	
	
	var myDiv = $('#cat');
	myDiv.on('click', function(){
	alert("안녕하세용");
	}
	);
});	//   << 여기 주의.